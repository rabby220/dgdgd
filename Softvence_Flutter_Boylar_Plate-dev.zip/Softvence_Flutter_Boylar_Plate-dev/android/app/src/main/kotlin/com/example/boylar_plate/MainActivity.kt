package com.example.boylar_plate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
