// import 'package:provider/provider.dart';
// import '../provider/internet_connection_provider.dart';

// var providers = [
//   // ChangeNotifierProvider<EmailProvider>(create: ((context) => EmailProvider())),

//   // ChangeNotifierProvider(create: (_) => InternetConnectionProvider()),

//   // ChangeNotifierProvider<SubscriptionProvider>(
//   //     create: ((context) => SubscriptionProvider())),

//   ChangeNotifierProvider<InternetConnectionProvider>(
//       create: ((context) => InternetConnectionProvider())),

//   // ChangeNotifierProvider<DateTimeProvider>(
//   //   create: ((context) => DateTimeProvider()),
//   // ),
// ];
