// // import 'package:flutter/foundation.dart';

// // final class EmailProvider extends ChangeNotifier {
// //   String _email = " ";
// //   String _password = " ";
// //   String get email => _email;
// //   String get passwordProvider => _password;
// //   changeemail(String email) async {
// //     _email = email;
// //     notifyListeners();
// //   }

// //   changepass(String password) async {
// //     _password = password;
// //     notifyListeners();
// //   }
// // }
// import 'package:flutter/foundation.dart';

// final class EmailProvider extends ChangeNotifier {
//   String _email = " ";
//   String _password = " ";

//   String get email => _email;
//   String get password => _password;

//   // Update email and notify listeners
//   void changeEmail(String email) async {
//     _email = email;
//     notifyListeners();
//   }

//   // Update password and notify listeners
//   void changePass(String password) async {
//     _password = password;
//     notifyListeners();
//   }
// }
