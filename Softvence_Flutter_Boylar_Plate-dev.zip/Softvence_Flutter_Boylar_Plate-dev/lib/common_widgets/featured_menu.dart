// import 'package:flutter/material.dart';

// import '../constants/text_font_style.dart';
// import '../gen/colors.gen.dart';

// class FeaturedMenu extends StatelessWidget {
//   final String name;
//   final VoidCallback callback;
//   const FeaturedMenu({
//     super.key,
//     required this.name,
//     required this.callback,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//       onTap: callback,
//       child: Chip(
//         backgroundColor: AppColors.cF4F4F4,
//         side: const BorderSide(color: AppColors.allPrimaryColor),
//         label: Text(
//           name,
//           style: TextFontStyle.textStyle14c292E34DmSans700,
//         ),
//       ),
//     );
//   }
// }
